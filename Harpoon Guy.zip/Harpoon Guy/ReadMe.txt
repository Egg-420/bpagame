Harpoon Guy is a thrilling action game where you play as a skilled harpooner taking down dangerous monsters and competing for the high score.

Gameplay
In Harpoon Guy, you control a character armed with a trusty harpoon gun. 
Your goal is to aim and shoot at various monsters and traps that appear on the screen, ranging from small slimes to massive boulders. 
As you progress through the game, the creatures will become more prevalent and more difficult to defeat.
To shoot your harpoon, use the left mouse button. 
You can also use the harpoon to move your character around the screen. 
Be careful not to get hit by the purple force – if you do, it's game over!

Features
Fast-paced action: keep your reflexes sharp as you take on increasingly challenging creatures.
Endless levels: each level brings new challenges and obstacles to overcome.
Competitive gameplay: compete against other players or yourself for the top highscore.
Fun and colorful graphics: enjoy vibrant, cartoon-style graphics as you play.

Requirements
Harpoon Guy requires a computer, a monitor, and a computer mouse.

How to Play
Download the game.
Unzip the game on your computer.
Launch the game and click "Start" to begin playing.
Press and hold the left mouse button to shoot your harpoon to move around the screen.
Try to earn as many points as possible by collecting coins and reaching new levels.

We hope you have a blast playing Harpoon Guy!
